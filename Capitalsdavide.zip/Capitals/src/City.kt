data class City(val name: String)
